from moviepy.editor import TextClip, CompositeVideoClip

def create_subtitles(video_clip, segments):
    """
    Crea subtítulos dinámicos y estilizados.
    segments: lista de diccionarios {start, end, text} de whisper
    """
    clips = [video_clip]
    
    for seg in segments:
        # Estilo profesional: Fuente gruesa, color amarillo/blanco, borde negro
        txt = TextClip(
            seg['text'].upper(),
            fontsize=70,
            color='yellow',
            font='Arial-Bold',
            stroke_color='black',
            stroke_width=2,
            method='caption',
            size=(video_clip.w * 0.8, None)
        ).set_start(seg['start']).set_end(seg['end']).set_position(('center', video_clip.h * 0.7))
        
        clips.append(txt)
        
    return CompositeVideoClip(clips)
