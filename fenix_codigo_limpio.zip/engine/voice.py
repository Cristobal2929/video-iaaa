from gtts import gTTS
import os

def generar_voz(texto, output_path):
    print("PASO 2: Generando voz...")
    
    tts = gTTS(texto, lang='es')
    tts.save(output_path)

    print("VOZ GENERADA")
