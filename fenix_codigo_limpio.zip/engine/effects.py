import numpy as np


# 📳 SHAKE PRO
def shake_frame(frame, intensity=8):
    dx = np.random.randint(-intensity, intensity)
    dy = np.random.randint(-intensity, intensity)

    h, w = frame.shape[:2]

    x1 = max(0, dx)
    y1 = max(0, dy)
    x2 = min(w, w + dx)
    y2 = min(h, h + dy)

    return frame[y1:y2, x1:x2]


# ⚡ FLASH
def flash(frame, strength=1.4):
    return np.clip(frame * strength, 0, 255)


# 🔍 ZOOM PULSE
def zoom(frame, zoom=1.1):
    h, w = frame.shape[:2]

    nh, nw = int(h / zoom), int(w / zoom)

    y1 = (h - nh) // 2
    x1 = (w - nw) // 2

    return frame[y1:y1+nh, x1:x1+nw]


# 🎬 COMBINADO CAPCUT STYLE
def apply_beat_fx(frame, beat_hit):
    if beat_hit:
        frame = shake_frame(frame)
        frame = flash(frame)
    return frame
