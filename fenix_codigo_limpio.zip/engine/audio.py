import numpy as np

def detect_beats(audio, fps):
    if len(audio.shape) > 1:
        audio = audio.mean(axis=1)

    step = int(fps * 0.03)  # más preciso (30ms)
    energy = []

    for i in range(0, len(audio), step):
        chunk = audio[i:i+step]
        energy.append(np.sum(np.abs(chunk)))

    energy = np.array(energy)

    mean = np.mean(energy)
    std = np.std(energy)

    threshold = mean + std * 1.2

    beats = np.where(energy > threshold)[0]

    return beats
