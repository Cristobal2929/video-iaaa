import os
import yt_dlp
from moviepy import VideoFileClip
from engine.generator import create_reel

def run_pipeline(query, workspace_path=None):
    print(f"\n[PIPELINE] 🔍 Buscando material cinematográfico para: '{query}'")

    work_dir = workspace_path if workspace_path else "output"
    os.makedirs(work_dir, exist_ok=True)

    # BLINDAJE YT-DLP ACTIVADO
    ydl_opts = {
        'format': 'bestvideo[height<=720][ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best',
        'outtmpl': f'{work_dir}/%(id)s.%(ext)s',
        'merge_output_format': 'mp4',
        'noplaylist': True,
        'ignoreerrors': True,  # 🛡️ Ignora vídeos borrados o privados automáticamente
        'quiet': True,         # 🤫 Apaga las advertencias de JS Runtime
        'no_warnings': True,
        'nocheckcertificate': True
    }

    video_paths = []
    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            # Buscamos 8 vídeos con términos épicos para dar el pego de IA/Documental
            search_query = f"ytsearch8:{query} cinematic b-roll OR {query} midjourney AI"
            print(f"[PIPELINE] 📥 Descargando metraje de alta calidad sobre: {query}...")
            
            info = ydl.extract_info(search_query, download=True)
            
            if info and 'entries' in info:
                for entry in info['entries']:
                    if not entry:
                        continue
                    filename = ydl.prepare_filename(entry)
                    base = os.path.splitext(filename)[0]
                    mp4_file = base + ".mp4"
                    
                    path_to_check = mp4_file if os.path.exists(mp4_file) else filename
                    if os.path.exists(path_to_check):
                        video_paths.append(path_to_check)
    except Exception as e:
        print(f"[PIPELINE] ⚠️ Aviso interno de yt-dlp (ignorado): {e}")

    # 🛡️ FILTRO INTELIGENTE ANTIMIERDA
    archivos_validos = []
    print("[PIPELINE] 🕵️ Filtrando vídeos corruptos o vacíos...")
    
    for path in video_paths:
        try:
            clip = VideoFileClip(path)
            # Solo si el vídeo se abre bien y dura más de 2 segundos
            if getattr(clip, 'reader', None) is not None and getattr(clip, 'duration', 0) > 2:
                archivos_validos.append(path)
            clip.close()
        except Exception as e:
            print(f"   🗑️ Descartando vídeo corrupto: {path}")
            try:
                os.remove(path)
            except:
                pass

    if not archivos_validos:
        raise Exception("Todos los vídeos encontrados estaban bloqueados o corruptos. Intenta con un tema diferente.")

    print(f"[PIPELINE] ✅ {len(archivos_validos)} vídeos de archivo listos. Pasando a Post-Producción...")

    nombre_limpio = query.replace(" ", "_").lower()
    output_path = os.path.join(work_dir, f"fenix_{nombre_limpio}.mp4")

    # Mandamos los vídeos limpios al generador
    create_reel(input_video=archivos_validos, output_path=output_path, title=query)

    print(f"[PIPELINE] 🎉 Documental generado con éxito en: {output_path}")
    return output_path
