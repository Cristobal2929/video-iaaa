import os
import urllib.request
import json
import traceback
from moviepy import VideoFileClip, concatenate_videoclips, AudioFileClip, TextClip, CompositeVideoClip, vfx, afx, CompositeAudioClip

# COLORES TERMINAL
C, G, Y, R, W, B = "\033[96m", "\033[92m", "\033[93m", "\033[91m", "\033[0m", "\033[1m"

os.environ["IMAGEMAGICK_BINARY"] = "/usr/bin/convert"
GEMINI_API_KEY = "AIzaSyAdAFK-T1WeqoFhpJT35hItvH3ktnW6-js"

def generar_guion_documental(tema):
    url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-latest:generateContent?key={GEMINI_API_KEY}"
    prompt = (
        f"Actúa como un narrador de documentales de misterio. "
        f"Escribe una historia fascinante y poco conocida sobre '{tema}'. "
        "Debe tener exactamente entre 130 y 150 palabras para durar 1 minuto exacto. "
        "Usa un tono oscuro, épico y revelador. Empieza con un gancho brutal que atrape al instante. "
        "Escribe SOLO el texto que va a ser narrado, sin comillas, ni emojis."
    )
    data = {"contents": [{"parts": [{"text": prompt}]}]}
    try:
        req = urllib.request.Request(url, headers={'Content-Type': 'application/json'}, data=json.dumps(data).encode('utf-8'))
        with urllib.request.urlopen(req) as response:
            result = json.loads(response.read().decode())
            texto = result['candidates'][0]['content']['parts'][0]['text'].strip()
            return texto.replace('*', '').replace('"', '')
    except Exception as e:
        print(f"{R}Error Gemini: {e}{W}")
        return "Nos han ocultado la verdad durante siglos. Lo que estás a punto de ver cambiará tu forma de entender el mundo. Prepárate, porque la historia no es como te la contaron. Acompáñame."

def agrupar_palabras(texto, palabras_por_grupo=4):
    palabras = texto.split()
    grupos = []
    for i in range(0, len(palabras), palabras_por_grupo):
        grupos.append(" ".join(palabras[i:i+palabras_por_grupo]))
    return grupos

def create_reel(input_video, output_path, title="FENIX"):
    try:
        print(f"\n{C}{B}╔══════════════════════════════════════════════╗{W}")
        print(f"{C}{B}║     FENIX AI - MODO DOCUMENTAL FACELLES      ║{W}")
        print(f"{C}{B}╚══════════════════════════════════════════════╝{W}")
        
        # 1. GUION
        print(f"{Y}📝 Redactando guion épico sobre: {title}...{W}")
        guion = generar_guion_documental(title)
        
        # 2. VOZ NEURONAL
        print(f"{Y}🎙️ Generando locución...{W}")
        audio_voz_path = "voz_temp.mp3"
        os.system(f'python3 -m edge_tts --voice "es-ES-AlvaroNeural" --text "{guion}" --write-media "{audio_voz_path}"')
        
        voz_clip = AudioFileClip(audio_voz_path)
        duracion_total = voz_clip.duration
        print(f"{G}⏱️ Duración del audio: {duracion_total:.2f} segundos.{W}")

        # 3. MÚSICA DE FONDO
        if os.path.exists("bg_music.mp3"):
            musica = AudioFileClip("bg_music.mp3")
            musica = afx.audio_loop(musica, duration=duracion_total).with_effects([afx.Volumex(0.08)])
            audio_final = CompositeAudioClip([voz_clip, musica])
        else:
            audio_final = voz_clip

        # 4. PROCESAR VÍDEOS (HD Vertical Seguro)
        print(f"{Y}🎬 Adaptando clips al formato vertical...{W}")
        clips_procesados = []
        for path in input_video:
            try:
                clip = VideoFileClip(path).without_audio().resized(height=1280).cropped(x_center=720/2, width=720)
                clips_procesados.append(clip)
            except:
                continue

        if not clips_procesados:
            raise Exception("No se pudo procesar la imagen de los clips.")

        # Multiplicamos la lista de clips hasta asegurar que cubrimos el minuto de audio
        clips_bucle = []
        duracion_actual = 0
        while duracion_actual < duracion_total:
            for c in clips_procesados:
                clips_bucle.append(c)
                duracion_actual += c.duration
                if duracion_actual >= duracion_total:
                    break

        video_unido = concatenate_videoclips(clips_bucle, method="compose").subclipped(0, duracion_total)
        video_fondo = video_unido.with_audio(audio_final)

        # 5. SUBTÍTULOS ESTILO HORMOSI (Legibles y dinámicos)
        print(f"{Y}✍️ Sincronizando subtítulos amarillos...{W}")
        frases = agrupar_palabras(guion, 4)
        dur_por_frase = duracion_total / len(frases)
        
        subs = []
        for i, frase in enumerate(frases):
            txt = TextClip(font="roboto.ttf", text=frase.upper(), font_size=75, color='#FFFF00', stroke_color='black', stroke_width=10, size=(650, None), method='caption')
            txt = txt.with_position(('center', 'center')).with_start(i * dur_por_frase).with_duration(dur_por_frase)
            subs.append(txt)

        # 6. RENDERIZADO
        print(f"{Y}⚙️ Renderizando (Esto tomará unos minutos en Termux)...{W}")
        final_video = CompositeVideoClip([video_fondo] + subs)
        final_video.write_videofile(output_path, fps=24, codec="libx264", audio_codec="aac", preset="ultrafast", logger=None)

        # Limpieza
        video_fondo.close(); final_video.close(); voz_clip.close()
        for c in clips_procesados: c.close()
        if os.path.exists(audio_voz_path): os.remove(audio_voz_path)

    except Exception as e:
        print(f"{R}❌ Error en producción: {e}{W}")
        traceback.print_exc()

    return True
