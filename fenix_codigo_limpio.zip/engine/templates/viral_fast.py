import numpy as np
from engine.effects import apply_beat_fx

# 🔥 CONFIG VIRAL TIKTOK
TEMPLATE = {
    "max_duration": 12,
    "zoom_intensity": 1.15,
    "shake_intensity": 10,
    "text_size": 90,
    "subtitle_position": ("center", 800),
    "beat_flash": True,
}


# 🎬 EFFECT WRAPPER
def apply_template(get_frame, t, beats):

    def fx(get_frame, t):
        frame = get_frame(t)

        hit = any(abs(t - bt) < 0.05 for bt in beats)

        if hit:
            frame = apply_beat_fx(frame, True)

        # 🔥 zoom dinámico viral
        zoom = 1.0 + 0.03 * np.sin(t * 6)
        h, w = frame.shape[:2]

        nh, nw = int(h / zoom), int(w / zoom)

        y1 = (h - nh) // 2
        x1 = (w - nw) // 2

        return frame[y1:y1+nh, x1:x1+nw]

    return fx
