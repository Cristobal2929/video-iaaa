import os

WHISPER_PATH = "/root/project_fenix/whisper.cpp/build/bin/whisper-cli"
MODEL_PATH = "/root/project_fenix/whisper.cpp/models/ggml-base.bin"


def transcribe(video_path):

    print("[WHISPER] extrayendo audio...")

    audio = "temp.wav"
    os.system(f'ffmpeg -y -i "{video_path}" -ar 16000 -ac 1 {audio}')

    print("[WHISPER] transcribiendo...")

    os.system(f'{WHISPER_PATH} -m {MODEL_PATH} -f {audio} -otxt')

    subtitles = []

    if os.path.exists("temp.txt"):
        with open("temp.txt", "r") as f:
            lines = f.readlines()

        for i, line in enumerate(lines):
            subtitles.append({
                "start": i * 2,
                "end": (i + 1) * 2,
                "text": line.strip()
            })

    print("[WHISPER] listo ✔")

    return subtitles
