import requests

# Reemplaza con tu TOKEN de BotFather y tu ID de Chat
TELEGRAM_TOKEN = "TU_TOKEN_AQUI"
ADMIN_CHAT_ID = "TU_CHAT_ID_AQUI"

def send_telegram_msg(message):
    try:
        url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"
        payload = {"chat_id": ADMIN_CHAT_ID, "text": message, "parse_mode": "HTML"}
        requests.post(url, json=payload, timeout=5)
    except Exception as e:
        print(f"[ERROR TELEGRAM] {e}")
