import os
import uuid
import yt_dlp
from moviepy import VideoFileClip

def descargar_videos(tema, output_dir="videos", max_videos=6):
    os.makedirs(output_dir, exist_ok=True)
    carpeta = os.path.join(output_dir, str(uuid.uuid4()))
    os.makedirs(carpeta, exist_ok=True)

    print(f"\n[PIPELINE] 📥 Buscando material (Modo API Nativa): {tema}")

    ydl_opts = {
        'format': 'bestvideo[height<=720][ext=mp4]+bestaudio[ext=m4a]/best[height<=720][ext=mp4]/best',
        'outtmpl': f'{carpeta}/%(id)s.%(ext)s',
        'ignoreerrors': True,
        'quiet': True,
        'no_warnings': True,
        'nocheckcertificate': True
    }

    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            ydl.download([f"ytsearch{max_videos}:{tema} clips"])
    except Exception as e:
        print(f"[PIPELINE] ⚠️ Aviso interno: {e}")

    # 🛡️ EL FILTRO INTELIGENTE (LA MAGIA ANTIMIERDA)
    archivos_validos = []
    print("[PIPELINE] 🕵️ Filtrando vídeos corruptos...")
    
    for f in os.listdir(carpeta):
        path = os.path.join(carpeta, f)
        if path.endswith(".mp4") or path.endswith(".mkv"):
            try:
                # Intentamos abrir el vídeo con MoviePy
                clip = VideoFileClip(path)
                
                # Si se abre bien, tiene duración y lector válido, lo guardamos
                if clip.reader is not None and clip.duration is not None and clip.duration > 2:
                    archivos_validos.append(path)
                clip.close() # Cerramos el archivo para no saturar la memoria
                
            except Exception as e:
                # Si MoviePy da error, el vídeo está corrupto. Lo borramos.
                print(f"   🗑️ Eliminando vídeo corrupto: {f}")
                try:
                    os.remove(path)
                except:
                    pass

    if not archivos_validos:
        print("[PIPELINE] ❌ Ningún vídeo superó el control de calidad.")
        return None

    print(f"[PIPELINE] ✅ {len(archivos_validos)} vídeos 100% sanos y listos para usar.")
    return archivos_validos
