from googleapiclient.discovery import build
from config import YOUTUBE_API_KEY


# ------------------------------
# FENIX YOUTUBE AI SEARCH ENGINE
# ------------------------------

def search_videos(query, max_results=5):
    """
    Busca vídeos en YouTube por keyword
    y devuelve lista de resultados optimizados.
    """

    if not YOUTUBE_API_KEY:
        raise ValueError("YOUTUBE_API_KEY no está configurada en config.py")

    youtube = build(
        "youtube",
        "v3",
        developerKey=YOUTUBE_API_KEY
    )

    # 🔥 optimización para contenido faceless / viral
    optimized_query = f"{query} stock footage broll animation faceless no face cinematic"

    request = youtube.search().list(
        q=optimized_query,
        part="snippet",
        type="video",
        maxResults=max_results
    )

    response = request.execute()

    videos = []

    for item in response.get("items", []):
        videos.append({
            "title": item["snippet"]["title"],
            "video_id": item["id"]["videoId"],
            "channel": item["snippet"]["channelTitle"]
        })

    return videos


# ------------------------------
# CONVERTIDOR DE URL
# ------------------------------

def get_video_url(video_id):
    """
    Convierte video_id en URL directa
    """

    return f"https://www.youtube.com/watch?v={video_id}"
