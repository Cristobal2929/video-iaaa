from moviepy import TextClip


def build_karaoke(words, video_duration):
    """
    words = [
        {"word": "hola", "start": 0.5, "end": 0.8},
        ...
    ]
    """

    clips = []

    for w in words:

        txt = TextClip(
            text=w["word"],
            font_size=85,
            color="white",
            stroke_color="black",
            stroke_width=4
        )

        clip = (
            txt
            .with_start(w["start"])
            .with_end(w["end"])
            .with_position(("center", 800))
            .with_opacity(1)
        )

        clips.append(clip)

    return clips
