def rank_videos(videos):

    print("[RANKER] evaluando videos...")

    if not videos:
        return None

    # MVP: elige el primero
    best = videos[0]

    print("[RANKER] elegido:", best["title"])

    return best
