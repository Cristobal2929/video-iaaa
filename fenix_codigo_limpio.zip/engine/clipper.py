import subprocess
import os


# =========================
# 🎬 VIRAL CLIP GENERATOR
# =========================

def generate_clips(video_path, output_dir="output/clips", clip_length=30):

    os.makedirs(output_dir, exist_ok=True)

    print("[CLIPPER] generando clips virales...")

    # 1. obtener duración total del vídeo
    duration = get_duration(video_path)

    clips = []

    start = 0
    index = 0

    # 2. cortar en segmentos
    while start < duration:

        end = min(start + clip_length, duration)

        output_file = f"{output_dir}/clip_{index}.mp4"

        cmd = [
            "ffmpeg",
            "-y",
            "-i", video_path,
            "-ss", str(start),
            "-to", str(end),
            "-c:v", "libx264",
            "-c:a", "aac",
            output_file
        ]

        subprocess.run(cmd)

        clips.append(output_file)

        print(f"[CLIPPER] clip creado: {output_file}")

        start += clip_length
        index += 1

    print("[CLIPPER] listo ✔")
    return clips


# =========================
# 📏 DURACIÓN VIDEO
# =========================

def get_duration(video_path):

    cmd = [
        "ffprobe",
        "-v", "error",
        "-show_entries", "format=duration",
        "-of", "default=noprint_wrappers=1:nokey=1",
        video_path
    ]

    result = subprocess.run(cmd, capture_output=True, text=True)

    try:
        return float(result.stdout.strip())
    except:
        return 60
