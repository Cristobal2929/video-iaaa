def search_videos(query):
    print("[YOUTUBE] search:", query)

    return [
        {"video_id": "dQw4w9WgXcQ", "title": "Video viral 1"},
        {"video_id": "9bZkp7q19f0", "title": "Video viral 2"},
        {"video_id": "3JZ_D3ELwOQ", "title": "Video viral 3"},
    ]
