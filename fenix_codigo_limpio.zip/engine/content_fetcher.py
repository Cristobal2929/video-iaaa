from googleapiclient.discovery import build

API_KEY = "TU_API_KEY"


def search_videos(query, max_results=5):
    youtube = build("youtube", "v3", developerKey=API_KEY)

    req = youtube.search().list(
        q=query,
        part="snippet",
        type="video",
        maxResults=max_results
    )

    res = req.execute()

    videos = []

    for item in res["items"]:
        videos.append({
            "title": item["snippet"]["title"],
            "video_id": item["id"]["videoId"]
        })

    return videos
