from engine.templates.viral_fast import apply_template

def get_template(name):
    if name == "viral_fast":
        return apply_template
    return apply_template
